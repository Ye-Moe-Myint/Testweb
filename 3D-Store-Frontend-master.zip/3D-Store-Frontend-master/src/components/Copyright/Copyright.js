import React from "react";
import "./Copyright.css";

const Copyright = () => {
  return <div className="copyright">© 2022 Wices. All Rights Reserved.</div>;
};

export default Copyright;
