import React, { useContext } from "react";
import { Navigate, Outlet, useLocation } from "react-router-dom";
import { AuthApi } from "../../../App";

const ProtectedRegister = () => {
  const location = useLocation();
  const Auth = useContext(AuthApi);

  return !Auth.auth ? (
    <Outlet />
  ) : (
    <Navigate to="/" state={{ from: location }} />
  );
};

export default ProtectedRegister;
