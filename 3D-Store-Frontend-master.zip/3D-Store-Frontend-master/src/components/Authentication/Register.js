import React, { useState } from "react";
import bcrypt from "bcryptjs";
import axios from "axios";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import AuthenticationCard from "../UI/AuthenticationCard/AuthenticationCard";
import "./Register.css";

// SALT should be created ONE TIME upon sign up
const salt = bcrypt.genSaltSync(10);

const Register = () => {
  const [name, setName] = useState("");
  const [fullName, setFullName] = useState("");
  const [company, setCompany] = useState("");
  const [password, setPassword] = useState("");

  const handleSubmit = (e) => {
    e.preventDefault();
    const hashedPassword = bcrypt.hashSync(password, salt);

    const data = {
      username: name,
      company: company,
      full_name: fullName,
      password: hashedPassword,
    };
    console.log(data);

    axios
      .post("http://127.0.0.1:8000/register", data)
      .then((response) => {
        console.log(response);
      })
      .catch((error) => console.log(error));

    setName("");
    setFullName("");
    setCompany("");
    setPassword("");
  };

  return (
    <AuthenticationCard>
      <form onSubmit={handleSubmit} className="register-form">
        <h3>Registration</h3>
        <div>
          <TextField
            id="textfield-username"
            label="Username"
            variant="standard"
            value={name}
            onChange={(e) => {
              setName(e.target.value);
            }}
          />
        </div>
        <div>
          <TextField
            id="textfield-fullname"
            label="Full Name"
            variant="standard"
            value={fullName}
            onChange={(e) => {
              setFullName(e.target.value);
            }}
          />
        </div>
        <div>
          <TextField
            id="textfield-company"
            label="Company"
            variant="standard"
            value={company}
            onChange={(e) => {
              setCompany(e.target.value);
            }}
          />
        </div>
        <div>
          <TextField
            id="textfield-password"
            label="password"
            variant="standard"
            type="password"
            value={password}
            onChange={(e) => {
              setPassword(e.target.value);
            }}
          />
        </div>
        <div>
          <Button
            variant="contained"
            type="submot"
            value="submit"
            sx={{
              backgroundColor: "hsl(26, 100%, 55%)",
              margin: "20px",
              maxWidth: "400px",
              minWidth: "180px",
              "&:hover": {
                backgroundColor: "hsl(26, 100%, 55%)",
              },
            }}
          >
            Submit
          </Button>
        </div>
      </form>
    </AuthenticationCard>
  );
};

export default Register;
