import React, { useState, useContext } from "react";
import { AuthApi } from "../../App";
import axios from "axios";
import Cookies from "js-cookie";
import TextField from "@mui/material/TextField";
import Button from "@mui/material/Button";
import AuthenticationCard from "../UI/AuthenticationCard/AuthenticationCard";
import "./Login.css";

const Login = () => {
  const Auth = useContext(AuthApi);

  const [username, setUsername] = useState("");
  const [password, setPassword] = useState("");

  const handleLogin = async (e) => {
    e.preventDefault();
    const request = new FormData();

    request.append("username", username);
    request.append("password", password);

    const news = async () => {
      const res = await axios
        .post("http://127.0.0.1:8000/login", request)
        .then((response) => {
          console.log(response);
          Cookies.set("token", response.data.access_token);
          return response;
        })
        .catch((error) => {
          console.log(error.message);
        });
      return res;
    };

    const x = await news();
    if (x) {
      window.location.reload();
    }
  };
  return (
    <AuthenticationCard>
      <form onSubmit={handleLogin} className="login-form">
        {Auth.auth ? (
          <div>You've already logged in.</div>
        ) : (
          <>
            <h3>Login</h3>
            <div>
              <TextField
                id="textfield-username"
                label="Username"
                variant="standard"
                value={username}
                onChange={(e) => {
                  setUsername(e.target.value);
                }}
              />
            </div>
            <div>
              <TextField
                id="textfield-password"
                label="password"
                variant="standard"
                type="password"
                value={password}
                onChange={(e) => {
                  setPassword(e.target.value);
                }}
              />
            </div>
            <div>
              <Button
                variant="contained"
                type="submot"
                value="submit"
                sx={{
                  backgroundColor: "hsl(26, 100%, 55%)",
                  margin: "20px",
                  maxWidth: "400px",
                  minWidth: "180px",
                  "&:hover": {
                    backgroundColor: "hsl(26, 100%, 55%)",
                  },
                }}
              >
                LOG IN
              </Button>
            </div>
          </>
        )}
      </form>
    </AuthenticationCard>
  );
};

export default Login;
