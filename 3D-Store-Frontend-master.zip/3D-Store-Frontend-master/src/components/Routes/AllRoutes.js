import React from "react";
import { BrowserRouter, Route, Routes } from "react-router-dom";
import Footer from "../Footer/Footer";
import LandingPage from "../LandingPage/LandingPage";
import Model3d from "../3D Models/Model3d";
import Aircraft3D from "../3D Models/aircraft-3d-model/Aircraft3D";
import ResponsiveNavbar from "../Header/ResponsiveNavbar";
import Register from "../Authentication/Register";
import Login from "../Authentication/Login";
import ProtectedRegister from "../Authentication/AuthLayout/ProtectedRegister";
import Upload from "../Upload/Upload";

const AllRoutes = () => {
  return (
    <BrowserRouter>
      <ResponsiveNavbar />
      <Routes>
        <Route path="/" element={<LandingPage />} />
        {/* <Route path="/signup" element={<Register />} /> */}
        <Route element={<ProtectedRegister />}>
          <Route path="/signup" element={<Register />} />
        </Route>
        <Route path="/login" element={<Login />} />
        <Route path="/upload" element={<Upload />} />

        <Route path="/3d-models" element={<Model3d />} />
        <Route path="/3d-models/aircraft" element={<Aircraft3D />} />
      </Routes>
      <Footer />
    </BrowserRouter>
  );
};

export default AllRoutes;
