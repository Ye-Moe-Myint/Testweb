import React, { useRef, useState } from "react";
import "./Footer.css";

const Footer = () => {
  const emailRef = useRef("");
  const [emailIsValid, setEmailIsValid] = useState("undefined");

  const subscribeSubmitHandler = (e) => {
    e.preventDefault();
    if (!emailRef.current.value.trim().includes("@")) {
      setEmailIsValid(false)
      return;
    } else {
      setEmailIsValid(true)
    }
    emailRef.current.value = "";
  };

  return (
    <footer>
      <div className="footer-container">
        <div className="footer-item">
          <h3>Company</h3>
          <ul>
            <li>
              <a href="#">Blog</a>
            </li>
            <li>
              <a href="#">Events</a>
            </li>
            <li>
              <a href="#">Carrers</a>
            </li>
            <li>
              <a href="#">Contact us</a>
            </li>
          </ul>
        </div>
        <div className="footer-item">
          <h3>Buy 3D Models</h3>
          <ul>
            <li>
              <a href="#">Freelance 3D Models</a>
            </li>
            <li>
              <a href="#">Free 3D Models</a>
            </li>
            <li>
              <a href="#">Sale</a>
            </li>
          </ul>
        </div>
        <div className="footer-item subscribe">
          <h3>Join the newsletter</h3>
          <p>Subscribe to get the latest content.</p>
          <form onSubmit={subscribeSubmitHandler}>
            <input
              aria-label="Your email address"
              name="email address"
              placeholder="Your email address"
              required
              ref={emailRef}
              // onChange={emailChangehandler}
            />
            <button>Subscribe</button>
          </form>
          {!emailIsValid ? <p style={{color: 'red'}}>Email is not valid</p> : ''}
        </div>
      </div>
    </footer>
  );
};

export default Footer;
