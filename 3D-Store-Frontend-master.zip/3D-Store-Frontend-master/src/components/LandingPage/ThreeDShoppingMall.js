import React from "react";
import "./ThreeDShoppingMall.css";
import ShoppingMallItem from "../UI/ShoppingMallItem";

const shoppingMallItems = [
  {
    image:
      "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60",
    title: "3D Models",
    description: "Lorem ipsum dolor sit amet, consectetur adipiscing elit",
  },
  {
    image:
      "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60",
    title: "3D Models",
    description: "sed do eiusmod tempor incididunt ut labore et",
  },
  {
    image:
      "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60",
    title: "3D Models",
    description: "Ut enim ad minim veniam, quis nostrud exercitation ",
  },
  {
    image:
      "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60",
    title: "3D Models",
    description: "Duis aute irure dolor in reprehenderit in voluptate",
  },
  {
    image:
      "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60",
    title: "3D Models",
    description: "dolore eu fugiat nulla pariatur. Excepteur sint",
  },
  {
    image:
      "https://images.unsplash.com/photo-1518791841217-8f162f1e1131?ixlib=rb-1.2.1&ixid=eyJhcHBfaWQiOjEyMDd9&auto=format&fit=crop&w=800&q=60",
    title: "3D Models",
    description: "non proident, sunt in culpa qui officia deserunt mollit",
  },
  
];

const ThreeDShoppingMall = () => {
  return (
    <section id="threeD-shoppingmall">
      <h3>3D Supermarket</h3>
      <p>
        The 3D shopping mall is a 3D model of a supermarket.The 3D shopping mall
        is a 3D model of a supermarket. The 3D shopping mall is a 3D model of a
        supermarket.The 3D shopping mall is a 3D model of a supermarket.
      </p>
      <div className="threeD-shoppingmall-categories">
        {shoppingMallItems.map((item, index) => {
          return (
            <ShoppingMallItem
              key={index}
              image={item.image}
              title={item.title}
              description={item.description}
            />
          );
        })}
      </div>
    </section>
  );
};

export default ThreeDShoppingMall;
