import React from "react";
import FeatureCard from "../UI/FeatureCard";
import ViewInArIcon from "@mui/icons-material/ViewInAr";
import CheckIcon from "@mui/icons-material/Check";
import "./Features.css";

const features = [
  {
    icon: <ViewInArIcon className="feature-icon" />,
    title: "Feature 1",
    description: "loream ipsum dolor sit amet, consectetur adipiscing elit",
  },
  {
    icon: <CheckIcon className="feature-icon" />,
    title: "Feature 2",
    description: "loream ipsum dolor sit amet, consectetur adipiscing elit",
  },
  {
    icon: <CheckIcon className="feature-icon" />,
    title: "Feature 3",
    description: "loream ipsum dolor sit amet, consectetur adipiscing elit",
  },
  {
    icon: <CheckIcon className="feature-icon" />,
    title: "Feature 4",
    description: "loream ipsum dolor sit amet, consectetur adipiscing elit",
  },
]; 

const Features = () => {
  return (
    <section className="landing-page-features">
      {features.map((feature, index) => {
        return (
          <FeatureCard
            key={index}
            icon={feature.icon}
            title={feature.title}
            description={feature.description}
          />
        );
      })}
    </section>
  );
};

export default Features;
