import React from "react";
import "./Hero.css";

const Hero = () => {
  return (
    <main className="landing-page-hero">
      <div className="landing-page-hero-content">
        <h2>lorem ipsum dolor sit amet consectetur adipisicing elit.</h2>
        <p>
          lorem ipsum dolor sit amet consectetur adipisicing elit. lorem ipsum
          dolor sit amet consectetur adipisicing elit. lorem ipsum dolor sit
          amet consectetur adipisicing elit.
        </p>
      </div>
          <div className="landing-page-hero-image" >
              <img src="/images/landingpage/thai.png" alt="heroimage1" />
      </div>
    </main>
  );
};

export default Hero;
