import React from 'react'
import Features from './Features'
import Hero from './Hero'
import ThreeDShoppingMall from './ThreeDShoppingMall'

const LandingPage = () => {
  return (
    <div className='landing-page'>
      <Hero />
      <Features />
      <ThreeDShoppingMall />
    </div>
  )
}

export default LandingPage