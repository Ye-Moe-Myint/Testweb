import { initializeApp } from "firebase/app";
import { getStorage } from "firebase/storage";

const firebaseConfig = {
  apiKey: "AIzaSyDZlFf6dxR2D7Rmw4Y4GBK94Kq1kRcp1AQ",
  authDomain: "auth-development-87bba.firebaseapp.com",
  databaseURL:
    "https://auth-development-87bba-default-rtdb.asia-southeast1.firebasedatabase.app",
  projectId: "auth-development-87bba",
  storageBucket: "auth-development-87bba.appspot.com",
  messagingSenderId: "229924193063",
  appId: "1:229924193063:web:50123b0399a9e9b44e5f02",
  measurementId: "G-RWPXRXDG43",
};

const app = initializeApp(firebaseConfig);

//firebase storage reference
const storage = getStorage(app);

export default storage;
