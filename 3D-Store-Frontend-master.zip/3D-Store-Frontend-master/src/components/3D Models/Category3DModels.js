import React from "react";
import CategoryCard from "../UI/CategoryCard";
import "./Category3DModels.css";

const Category3DModels_list = [
  {
    id: 1,
    name: "Aircraft 3D Models",
    image: "https://source.unsplash.com/random/500x300",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    types: ["Aircraft", "Planes", "Airplanes", "Aircrafts"],
  },
  {
    id: 2,
    name: "Animal 3D Models",
    image: "https://source.unsplash.com/random/500x300",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    types: ["Dog", "Cat", "Bird", "Rabbit", "Lion", "Tiger"],
  },
  {
    id: 3,
    name: "Architectural 3D Models",
    image: "https://source.unsplash.com/random/500x300",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    types: ["Architectural", "Building", "House", "Office", "Office", "Office"],
  },
  {
    id: 4,
    name: "Exterior 3D Models",
    image: "https://source.unsplash.com/random/500x300",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    types: ["Exterior", "House", "Office", "Office"],
  },
  {
    id: 5,
    name: "Interior 3D Models",
    image: "https://source.unsplash.com/random/500x300",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    types: ["Interior", "House", "Office", "Office", "Office"],
  },
  {
    id: 6,
    name: "Car 3D Models",
    image: "https://source.unsplash.com/random/500x300",
    description: "lorem ipsum dolor sit amet consectetur adipisicing elit.",
    types: ["Car", "Car", "Car", "Car", "Car", "Car"],
  },
];

const Category3DModels = () => {
  return (
    <section id="Models3d-Category">
      <h3>Search Your 3D Categories</h3>
      <p>
        lorem ipsum dolor sit amet consectetur adipisicing elit. lorem ipsum
        dolor sit amet consectetur adipisicing elit. lorem ipsum dolor sit amet
        consectetur adipisicing elit. lorem ipsum dolor sit amet consectetur
        adipisicing elit. lorem ipsum dolor sit amet consectetur adipisicing
        elit. lorem ipsum dolor sit amet consectetur adipisicing elit. lorem
        ipsum dolor sit amet consectetur adipisicing elit.
      </p>
      <div className="category-card-container">
        {Category3DModels_list.map((category) => (
          <CategoryCard
            key={category.id}
            name={category.name}
            image={category.image}
            description={category.description}
            types={category.types}
          />
        ))}
      </div>
    </section>
  );
};

export default Category3DModels;
