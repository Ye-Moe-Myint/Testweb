import React from "react";
import "./GalleryControl.css";
import Pagination from "@mui/material/Pagination";

const GalleryControl = () => {
  return (
    <div className="gallerycontrol">
      <Pagination count={5} variant="outlined" shape="rounded"/>
    </div>
  );
};

export default GalleryControl;
