import React from "react";
import ModelGalleryCard from "../../UI/ModelgalleryCard/ModelGalleryCard";
import ModelCounts from "../ModelCounts";
import "./ModelsGallery.css";

const models = [
  {
    modelName: "Aircraft 3D model",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 1",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 2",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 3",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 4",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 5",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 6",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 7",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 8",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 9",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 10",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 11",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 12",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 13",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 14",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
  {
    modelName: "Aircraft 3D model 15",
    price: "100",
    format: "fbx",
    image: "https://source.unsplash.com/random/250x200",
  },
];

const ModelsGallery = () => {
  return (
    <div className="modelsgallery">
      <ModelCounts />
      <div className="modelsgallery_gallery">
        {models.map((model) => {
          return ( 
            <ModelGalleryCard
              key={model.modelName}
              modelName={model.modelName}
              price={model.price}
              format={model.format}
              image={model.image}
            />
          );
        })} 
      </div>
    </div>
  );
};

export default ModelsGallery;
