import React from 'react'
import Hero from '../LandingPage/Hero'
import Category3DModels from './Category3DModels'
import '../LandingPage/Hero.css'


const Model3d = () => {
  return (
      <div>
          <Hero />
          <Category3DModels />
      </div>
  )
}

export default Model3d