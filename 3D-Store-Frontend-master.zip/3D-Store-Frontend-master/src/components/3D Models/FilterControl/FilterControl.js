import React from "react";
import CloseIconCustomize from "../../UI/Icons/CloseIconCustomize";
import FilterContent from "../../UI/Filter/FIlterControlContent/FilterContent";
import "./FilterControl.css";

const FilterControl = () => {
  return ( 
    <div className="filtercontrol">
      <div className="filtercontrol_content filtercontrol_name">
        <span>aircraft</span>
        <button>
          <CloseIconCustomize styleColor='white'/>
        </button>
      </div>
      <div className="filtercontrol_content filtercontrol_reset">
        <button>
          <CloseIconCustomize />
        </button>
        <span>Reset filters</span>
      </div>
    </div>
  );
};

export default FilterControl;
