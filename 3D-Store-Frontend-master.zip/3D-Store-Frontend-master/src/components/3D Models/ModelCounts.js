import React from 'react'

const ModelCounts = () => {
  return (
    <div>2228282 items</div>
  )
}

export default ModelCounts