import React from "react";
import Filter from "../../UI/Filter/Filter";
import FilterControl from "../FilterControl/FilterControl";
import GalleryControl from "../ModelsGallery/GalleryControl";
import ModelsGallery from "../ModelsGallery/ModelsGallery";
import "./Aircraft3D.css";

const Aircraft3D = () => {
  return (
    <div className="aircraft3d">
      <h4>Aircraft 3D models</h4>
      <p>
        loream ipsum dolor sit amet, consectetur adipiscing elit. Suspendisse
        euismod, nisi vel consectetur euismod, nisi nisl aliquet nisi, eget
        consectetur nisi nisl euismod. Suspendisse euismod, nisi vel consectetur
        euismod, nisi nisl aliquet nisi, eget consectetur nisi nisl euismod.
        Suspendisse euismod, nisi vel consectetur euismod, nisi nisl aliquet
        nisi, eget consectetur nisi nisl euismod. Suspendisse euismod, nisi vel
        consectetur euismod,
      </p>
      <Filter />
      <FilterControl />
      <ModelsGallery />
      <GalleryControl />
    </div>
  );
};

export default Aircraft3D;
