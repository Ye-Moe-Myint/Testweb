import React from "react";
import ShoppingCartOutlinedIcon from "@mui/icons-material/ShoppingCartOutlined";
import "./Header.css";
import { NavLink } from "react-router-dom";

const Header = () => {
  return (
    <section id="header">
      <nav>
        <ul>
          <li>
            <a href="/">
              <h3>Wices</h3>
            </a>
          </li>
          <li>
            <NavLink to="/3d-models">3D Models</NavLink>
          </li>
          <li>
            <a href="#">About</a>
          </li>
          <li>
            <a href="#">Contact</a>
          </li>
        </ul>
        <ul>
          <li>
            <a href="#">
              <ShoppingCartOutlinedIcon />
            </a>
          </li>
          <li>
            <a href="#">Login</a>
          </li>
        </ul>
      </nav>
    </section>
  );
};

export default Header;
