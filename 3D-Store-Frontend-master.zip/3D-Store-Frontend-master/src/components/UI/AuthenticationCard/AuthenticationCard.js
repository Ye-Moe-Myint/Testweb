import React from "react";
import "./AuthenticationCard.css";

const AuthenticationCard = (props) => {
  return <div className="authentication-card">{props.children}</div>;
};

export default AuthenticationCard;
