import React from "react";
import "./UploadCard.css";

const UploadCard = (props) => {
  return <div className="upload-card">{props.children}</div>;
};

export default UploadCard;
