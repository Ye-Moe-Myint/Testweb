import React from "react";
import "./ModelGalleryCard.css";

const ModelGalleryCard = (props) => {
  return (
    <div className="modelgallerycard">
      <div className="modelgallerycard-img-container"> 
        <img src={props.image} alt={props.modelName} className="modelgallerycard-img"/>
      </div>
      <div className="modelgallerycard_description">
        <h5>${props.price}</h5>
        <span>{props.format}</span>
      </div>
    </div> 
  );
};

export default ModelGalleryCard;
