import * as React from "react";
import { styled, alpha } from "@mui/material/styles";
import Button from "@mui/material/Button";
import Menu from "@mui/material/Menu";
import MenuItem from "@mui/material/MenuItem";
import KeyboardArrowDownIcon from "@mui/icons-material/KeyboardArrowDown";
import RangeSlider2 from "./RangeSlider2";
import Free3D from "./Free3D";
import Select from "./Select/Select";

const StyledMenu = styled((props) => (
  <Menu
    elevation={0}
    anchorOrigin={{
      vertical: "bottom",
      horizontal: "right",
    }}
    transformOrigin={{
      vertical: "top",
      horizontal: "right",
    }}
    {...props}
  />
))(({ theme }) => ({
  "& .MuiPaper-root": {
    borderRadius: 6,
    marginTop: theme.spacing(1),
    minWidth: 180,
    color:
      theme.palette.mode === "light"
        ? "rgb(55, 65, 81)"
        : theme.palette.grey[300],
    boxShadow:
      "rgb(255, 255, 255) 0px 0px 0px 0px, rgba(0, 0, 0, 0.05) 0px 0px 0px 1px, rgba(0, 0, 0, 0.1) 0px 10px 15px -3px, rgba(0, 0, 0, 0.05) 0px 4px 6px -2px",
    "& .MuiMenu-list": {
      padding: "4px 0",
    },
    "& .MuiMenuItem-root": {
      "& .MuiSvgIcon-root": {
        fontSize: 18,
        color: theme.palette.text.secondary,
        marginRight: theme.spacing(1.5),
      },
      "&:active": {
        backgroundColor: alpha(
          theme.palette.primary.main,
          theme.palette.action.selectedOpacity
        ),
      },
    },
  },
}));

const formatsOptions = [
  "lorem",
  "ipsum",
  "dolor",
  "sit",
  "amet",
  "consectetur",
  "adipiscing",
  "elit",
];

const polyCountOptions = [
  "up to 5k",
  "5k to 10k",
  "10k to 50k",
  "50k to 100k",
  "100k to 250k",
  "250k+",
];

const attributeOptions = [
  "Low-poly",
  "3D Print",
  "Animated",
  "PBR",
  "Rigged",
  "Collection",
  "Show Age+",
  "Flash 3D Model Sale",
];


const licenseOptions = ["Exclude Editorial"];

export default function FilterMobileComponent() {
  const [anchorEl, setAnchorEl] = React.useState(null);
  const open = Boolean(anchorEl);
  const handleClick = (event) => {
    setAnchorEl(event.currentTarget);
  };
  const handleClose = () => {
    setAnchorEl(null);
  };

  return (
    <div>
      <Button
        id="demo-customized-button"
        aria-controls={open ? "demo-customized-menu" : undefined}
        aria-haspopup="true"
        aria-expanded={open ? "true" : undefined}
        variant="contained"
        disableElevation
        onClick={handleClick}
        endIcon={<KeyboardArrowDownIcon />}
        sx={{ minWidth: 240 }}
      >
        Options
      </Button>
      <StyledMenu
        id="demo-customized-menu"
        MenuListProps={{
          "aria-labelledby": "demo-customized-button",
        }}
        anchorEl={anchorEl}
        open={open}
        onClose={handleClose}
      >
        <MenuItem onClick={handleClose} disableRipple>
          <RangeSlider2 />
        </MenuItem>
        <MenuItem onClick={handleClose} disableRipple>
          <Free3D />
        </MenuItem>
        <MenuItem disableRipple>
          <Select options={formatsOptions} title={"Formats"} />
        </MenuItem>
        <MenuItem disableRipple>
          <Select options={polyCountOptions} title={"Poly Count"} />
        </MenuItem>
        <MenuItem disableRipple>
          <Select options={licenseOptions} title={"Licnese"} />
        </MenuItem>
        <MenuItem disableRipple>
          <Select options={attributeOptions} title={"Select Attribute"} />
        </MenuItem>
      </StyledMenu>
    </div>
  );
}
