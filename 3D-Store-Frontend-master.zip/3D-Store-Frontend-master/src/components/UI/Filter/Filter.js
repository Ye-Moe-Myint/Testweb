import React from "react";
import Free3D from "./Free3D";
import Select from "./Select/Select";
import RangeSlider2 from "./RangeSlider2";
import useMediaQuery from "@mui/material/useMediaQuery";
import { useTheme } from "@mui/material/styles";
import FilterMobileComponent from "./FilterMobileComponent";
import FormControl from "@mui/material/FormControl";
import "./Filter.css";

const formatsOptions = [
  "lorem",
  "ipsum",
  "dolor",
  "sit",
  "amet",
  "consectetur",
  "adipiscing",
  "elit",
];

const polyCountOptions = [
  "up to 5k",
  "5k to 10k",
  "10k to 50k",
  "50k to 100k",
  "100k to 250k",
  "250k+",
];

const attributeOptions = [
  "Low-poly",
  "3D Print",
  "Animated",
  "PBR",
  "Rigged",
  "Collection",
  "Show Age+",
  "Flash 3D Model Sale",
];

const bestMatchOptions = [
  "Best Match",
  "Top Selling",
  "Newest",
  "Oldest",
  "Lower Price",
  "Higher Price",
];

const licenseOptions = ["Exclude Editorial"];

const Filter = () => {
  const theme = useTheme();
  const isMobile = useMediaQuery(theme.breakpoints.down("lg"));
  return (
    <section id="filter">
      {isMobile ? (
        <div>
          <FormControl sx={{ width: 240 }}>
            <FilterMobileComponent />
            <Select
              options={bestMatchOptions}
              title={"Best Match"}
              className="filter_bestmatch"
            />
          </FormControl>
        </div>
      ) : (
        <FormControl
          className="filter-formcontrol-desktop"
          sx={{ display: "flex", flexDirection: "row" }}
        >
          <RangeSlider2 />
          <Free3D />
          <Select options={formatsOptions} title={"Formats"} />
          <Select options={polyCountOptions} title={"Poly Count"} />
          <Select options={licenseOptions} title={"Licnese"} />
          <Select options={attributeOptions} title={"Select Attribute"} />
        </FormControl>
      )}

      {/* <RangeSlider2 />
      <Free3D />
      <Select options={formatsOptions} title={"Formats"} />
      <Select options={polyCountOptions} title={"Poly Count"} />
      <Select options={licenseOptions} title={"Licnese"} />
      <Select options={attributeOptions} title={"Select Attribute"} /> */}
    </section>
  );
};

export default Filter;
