import React, { useState } from "react";
import "./RangeSlider2.css";

const RangeSlider2 = () => {
  const [rangeUpperBound, setRangeUpperBound] = useState(0);
  const rangeBullet = document.getElementById("rs-bullet");

  const handleChange = (e) => {
    setRangeUpperBound(e.target.value);
    var bulletPosition = (e.target.value/200);
    rangeBullet.style.left = (bulletPosition * 100) + "px";
  };
  

  return (
    <div className="container">
      <div className="slidecontainer">
        <span id="rs-bullet" className="rs-label">${rangeUpperBound}</span>
        <input
          type="range"
          min="0"
          max="200"
          value={rangeUpperBound}
          onChange={handleChange}
          className="slider"
          id="myRange"
        />
      </div>
      <div className="box-minmax">
        <span>$0</span>
        <span>$200</span>
      </div>
    </div>
  );
};

export default RangeSlider2;
