import React from "react";
import CloseIconCustomize  from '../../Icons/CloseIconCustomize'
import './FilterContent.css'

const FilterContent = () => {
  return (
    <div className="filtercontrol_content filtercontrol_name">
      <span>aircraft</span>
      <button>
        <CloseIconCustomize styleColor="white" />
      </button>
    </div>
  );
};

export default FilterContent;
