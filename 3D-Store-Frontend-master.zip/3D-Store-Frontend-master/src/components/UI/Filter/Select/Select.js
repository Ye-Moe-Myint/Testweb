import React from "react";
import "./Select.css";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import SelectMui from "@mui/material/Select";

const Select = (props) => {
  return (
    <FormControl sx={{ minWidth: 180, mt: 1 }}>
      <InputLabel id="demo-simple-select-label">{props.title}</InputLabel>
      <SelectMui
        labelId="demo-simple-select-label"
        id="demo-simple-select"
        // value={age}
        label={props.title}
        className='filter-select'
        // onChange={handleChange}
      >
        {props.options.map((format) => {
          return (
            <MenuItem value={format} key={Math.random()}>
              {format}
            </MenuItem>
          );
        })}
      </SelectMui>
    </FormControl>
  );
};

export default Select;
