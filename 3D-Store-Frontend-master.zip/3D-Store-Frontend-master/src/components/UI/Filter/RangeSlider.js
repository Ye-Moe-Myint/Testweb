import React from "react";
import "./RangeSlider.css";

const RangeSlider = () => {
  const minHandler = (e) => {
    console.log(e.target);
  };

  const maxHandler = (e) => {
    console.log(e.target);
  }; 
  return (
    <div className="filter-rangeslider">
      <div className="filter-rangeslider-description">
        <div className="filter-randslider-min">$2</div>
        <div className="filter-randslider-max">$500+</div>
      </div>
      <div className="filter-rangeslider-slider">
        <div
          className="filter-rangeslider-slider-mincircle"
          onClick={minHandler}
        ></div>
        <div
          className="filter-rangeslider-slider-maxcircle"
          onClick={maxHandler}
        ></div>
        <div className="filter-rangeslider-slider-line"></div>
        <div className="filter-rangeslider-slider-line-background"></div>
      </div>
    </div>
  );
};

export default RangeSlider;
