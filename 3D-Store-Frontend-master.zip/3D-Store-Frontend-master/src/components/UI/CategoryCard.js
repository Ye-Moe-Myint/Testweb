import React from "react";
import "./CategoryCard.css";
import { useNavigate } from "react-router-dom";

const CategoryCard = (props) => {
  const navigate = useNavigate();

  const handleClick = () => {
    navigate(`/3d-models/aircraft`);
  };
  return (
    <div className="category-card" onClick={handleClick}>
      <div className="category-card-filter"></div>
      <div className="category-card-img-container">
        <img src={props.image} alt={props.name} className="category-card-img" />
      </div> 
      <div className="category-card-description">
        <h4>{props.name}</h4>
        <p>{props.description}</p>
        <ul className="category-card-description-typelists">
          {props.types.map((type) => {
            return <li key={Math.random()}>{type}</li>;
          })}
        </ul>
      </div>
    </div>
  );
};

export default CategoryCard;
