import React from "react";
import CloseIcon from "@mui/icons-material/Close";

const CloseIconCustomize = (props) => {
  return (
    <>
      <CloseIcon
        style={{ color: props.styleColor ? `${props.styleColor}` : "black", cursor: 'pointer' }}
      />
    </>
  );
};

export default CloseIconCustomize;
