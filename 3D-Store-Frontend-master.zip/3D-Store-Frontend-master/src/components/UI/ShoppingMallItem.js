import React from "react";
import { useNavigate } from "react-router-dom";
import "./ShoppingMallItem.css";

const ShoppingMallItem = (props) => {
  const navigate = useNavigate()
  const clickhandler = () => {
    navigate('/3d-models')
  }
  return (
    <div className="shoppingmall-item" onClick={clickhandler}>
      <div className="shoppingmall-item-image">
        <img src={props.image} alt={props.title} />
      </div>
      <div className="shoppingmall-item-title">
        <h3>{props.title}</h3>
      </div>
      <div className="shoppingmall-item-description">
        <p>{props.description}</p>
      </div>
      <div className="shoppingmall-item-viewall">
        <a href="#">View All &gt;</a>
      </div>
    </div>
  );
};

export default ShoppingMallItem;
