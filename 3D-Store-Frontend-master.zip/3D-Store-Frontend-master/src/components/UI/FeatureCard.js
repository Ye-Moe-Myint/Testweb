import React from "react";
import "./FeatureCard.css";

const FeatureCard = (props) => {
  return (
    <div className="feature-card">
      <div className="feature-card-icon">{props.icon}</div>
      <div className="feature-card-title"><h3>{props.title}</h3></div>
      <div className="feature-card-description">{props.description} </div>
    </div>
  ); 
};

export default FeatureCard;
