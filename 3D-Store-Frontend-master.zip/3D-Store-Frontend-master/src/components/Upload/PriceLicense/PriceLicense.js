import React from "react";
// import TextField from "@mui/material/TextField";
import FormControl from "@mui/material/FormControl";
import Input from "@mui/material/Input";
import InputLabel from "@mui/material/InputLabel";
import InputAdornment from "@mui/material/InputAdornment";
import MenuItem from "@mui/material/MenuItem";
import Select from "@mui/material/Select";
import "./PriceLicense.css";

const PriceLicense = (props) => {
  const handleChange = (e) => {
    props.setProperties((prevState) => {
      return { ...prevState, price: e.target.value };
    });
  };

  const handleChangeLicnese = (e) => {
    props.setProperties((prevState) => {
      return { ...prevState, license: e.target.value };
    });
  };
  return (
    <section id="upload-price-license">
      <h4>Price and Licnese</h4>
      <FormControl fullWidth sx={{ m: 1 }} variant="standard">
        <InputLabel htmlFor="standard-adornment-price">Price</InputLabel>
        <Input
          id="standard-adornment-price"
          value={props.properties.price}
          onChange={handleChange}
          startAdornment={<InputAdornment position="start">$</InputAdornment>}
        />
      </FormControl>
      <FormControl fullWidth sx={{ m: 1 }}>
        <InputLabel id="demo-simple-select-label">Licnese</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={props.properties.license}
          label="Age"
          onChange={handleChangeLicnese}
        >
          <MenuItem value={"Royalty Free"}>Royalty Free</MenuItem>
          <MenuItem value={"Editoral"}>Editoral</MenuItem>
        </Select>
      </FormControl>
    </section>
  );
};

export default PriceLicense;
