import React, { useState } from "react";
import UploadCard from "../../UI/UploadCard/UploadCard";
import UploadFiles from "../UploadFiles/UploadFiles";
import storage from "../../Firebase/FirebaseConfig";
import { getDownloadURL, ref, uploadBytesResumable } from "firebase/storage";
import "./ModelUpload.css";
import Properties from "../Properties/Properties";
import axios from "axios";

const ModelUpload = (props) => {
  const [firstImage, setFirstImage] = useState("");
  const [secondImage, setSecondImage] = useState("");
  const [thirdImage, setThirdImage] = useState("");
  const [threeDFile, setThreeDFile] = useState("");
  const [fileUrls, setFileUrls] = useState([]);
  const [properties, setProperties] = useState({
    category: "",
    price: "",
    license: "",
  });
  const [percent, setPercent] = useState(0);

  const uploadFilesPages = [
    {
      name: "1. Upload your preview photo",
      button: "Add preview photo",
      dropDescription: "Drag and drop a file or select add Image",
      file: firstImage,
      setFunction: setFirstImage,
    },
    {
      name: "2. Upload your preview photo",
      button: "Add preview photo",
      dropDescription: "Drag and drop a file or select add Image",
      file: secondImage,
      setFunction: setSecondImage,
    },
    {
      name: "3. Upload your preview photo",
      button: "Add preview photo",
      dropDescription: "Drag and drop a file or select add Image",
      file: thirdImage,
      setFunction: setThirdImage,
    },
    {
      name: "4. Upload your 3D file",
      button: "Add 3D file",
      dropDescription: "Drag and drop a file or select add 3D",
      file: threeDFile,
      setFunction: setThreeDFile,
    },
  ];

  //dom
  const loadingFillDom = document.querySelector(".uploadfiles-loading-fill");
  if (loadingFillDom) {
    console.log("loadingFillDom: ", loadingFillDom.style);
  }

  const handleSubmit = async () => {
    if (!firstImage) {
      alert("Please upload the first preview image");
    }
    if (!secondImage) {
      alert("Please upload the second preview image");
    }
    if (!thirdImage) {
      alert("Please upload the thrid preview image");
    }
    if (!threeDFile) {
      alert("Please upload the 3D File");
    }
    const allFiles = [firstImage, secondImage, thirdImage, threeDFile];

    allFiles.forEach((eachFile) => {
      const storageRef = ref(storage, `/files/htain/${eachFile.name}`);
      const uploadTask = uploadBytesResumable(storageRef, eachFile);

      uploadTask.on(
        "state_changed",
        (snapshot) => {
          const percent = Math.round(
            (snapshot.bytesTransferred / snapshot.totalBytes) * 100
          );
          setPercent(percent);
        },
        (err) => {
          console.log(err);
        },
        () => {
          getDownloadURL(ref(storage, `/files/htain/${eachFile.name}`)).then(
            (url) => {
              setFileUrls((prevState) => {
                return [...prevState, url];
              });
            }
          );
        }
      );
    });

    const data = {
      owner: props.currentUser.currentUser,
      previewOne: fileUrls[0],
      previewTwo: fileUrls[1],
      previewThree: fileUrls[2],
      threeDFile: fileUrls[3],
      category: properties["category"],
      price: properties["price"],
      license: properties["license"],
    };

    console.log('data: ', data)

    axios
      .post("http://127.0.0.1:8000/new_model", data, {
        headers: {
          Authorization: `Bearer ${props.token}`,
        },
      })
      .then((response) => {
        console.log(response);
      })
      .catch((error) => console.log(error));
  };

  return (
    <UploadCard>
      <h4>Instructions to upload the 3D file</h4>
      <p>
        Please upload 3 images to show as a preview and upload 3D file in 4.
      </p>
      {uploadFilesPages.map((uploadFilesPage) => (
        <UploadFiles
          key={uploadFilesPage.name}
          uploadFilesPage={uploadFilesPage}
        />
      ))}
      <Properties properties={properties} setProperties={setProperties} />
      <div>{percent}% done</div>
      <button className="uploadfiles-submit-btn" onClick={handleSubmit}>
        Publish
      </button>
    </UploadCard>
  );
};

export default ModelUpload;
