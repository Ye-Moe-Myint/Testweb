import React from "react";
import InputLabel from "@mui/material/InputLabel";
import MenuItem from "@mui/material/MenuItem";
import FormControl from "@mui/material/FormControl";
import Select from "@mui/material/Select";
import "./Category.css";

const Category = (props) => {
  const handleChange = (event) => {
    props.setProperties((prevState) => {
      return { ...prevState, category: event.target.value };
    });
  };

  return (
    <section id="upload-category">
      <h4>Category and subcategory</h4>
      <FormControl fullWidth>
        <InputLabel id="demo-simple-select-label">Category</InputLabel>
        <Select
          labelId="demo-simple-select-label"
          id="demo-simple-select"
          value={props.properties.category}
          label="Age"
          onChange={handleChange}
        >
          <MenuItem value={"Aircraft"}>Aircraft</MenuItem>
          <MenuItem value={"Animal"}>Animal</MenuItem>
          <MenuItem value={"Architectural"}>Architectural</MenuItem>
          <MenuItem value={"Exterior"}>Exterior</MenuItem>
          <MenuItem value={"Interior"}>Interior</MenuItem>
          <MenuItem value={"Car"}>Car</MenuItem>
        </Select>
      </FormControl>
    </section>
  );
};

export default Category;
