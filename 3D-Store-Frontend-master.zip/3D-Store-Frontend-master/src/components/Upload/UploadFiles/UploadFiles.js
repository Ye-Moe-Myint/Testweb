import React, { useState } from "react";
import "./UploadFiles.css";

const UploadFiles = (props) => {
  //file
  // const [file, setFile] = useState("");

  //progress
  const [percent, setPercent] = useState("");

  //handle change the file
  const handleChange = (e) => {
    props.uploadFilesPage.setFunction(e.target.files[0]);
  };

  //fileinput DOM
  const fileInput = document.querySelector(".file-upload-input");
  const handleFileInput = () => {
    fileInput.click();
  };

  return (
    <div className="uploadfiles-container">
      <h4>{props.uploadFilesPage.name}</h4>
      <button className="uploadfiles-container-btn" onClick={handleFileInput}>
        {props.uploadFilesPage.button}
      </button>
      <div className="image-upload-wrap">
        <input
          className="file-upload-input"
          type="file"
          onChange={handleChange}
          // accept="image/*"
        />
        <div className="drag-text">
          <h3>{props.uploadFilesPage.dropDescription}</h3>
        </div>
      </div>
      <div>{props.uploadFilesPage.file.name}</div>
      {/* <div className="uploadfiles-loading"> */}
        {/* <progress max="100" value="95">
          95%
        </progress> */}
      {/* </div> */}
    </div>
  );
};

export default UploadFiles;
