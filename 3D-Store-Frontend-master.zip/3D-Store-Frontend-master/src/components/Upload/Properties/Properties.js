import React from "react";
import Category from "../Category/Category";
import PriceLicense from "../PriceLicense/PriceLicense";

const Properties = (props) => {
  return (
    <div>
      <Category properties={props.properties} setProperties={props.setProperties} />
      <PriceLicense properties={props.properties} setProperties={props.setProperties}/>
    </div>
  );
};

export default Properties;
