import React, { createContext, useState, useEffect } from "react";
import Copyright from "./components/Copyright/Copyright";
import AllRoutes from "./components/Routes/AllRoutes";
import Cookies from "js-cookie";



export const AuthApi = createContext();
export const TokenApi = createContext();

function App() {
  const [auth, setAuth] = useState(false);
  const [token, setToken] = useState("");



  const readCookie = () => {
    const token = Cookies.get("token");
    if (token) {
      setAuth(true);
      setToken(token);
    }
  };
  // console.log("current user is: ", currentUser);

  useEffect(() => {
    readCookie();
  }, []);

  return (
    <>
      <AuthApi.Provider value={{ auth, setAuth }}>
        <TokenApi.Provider value={{ token, setToken }}>
          <AllRoutes />
        </TokenApi.Provider>
      </AuthApi.Provider>
      <Copyright />
    </>
  );
}

export default App;
